import dash_bootstrap_components as dbc

def make_fig(fig):
    return dbc.Label('Figure Section')