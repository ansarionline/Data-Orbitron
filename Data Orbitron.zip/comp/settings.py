import dash_bootstrap_components as dbc

def make_settings(fig):
    return dbc.Label('Settings Section')